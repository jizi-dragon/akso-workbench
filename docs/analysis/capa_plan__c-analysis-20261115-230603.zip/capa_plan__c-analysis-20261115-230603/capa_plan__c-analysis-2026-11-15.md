# CAPA（capa_plan__c）对象分析

> 数据环境：`https://tonbridge-config.aksoegmp.com`
> 数据账号：`lyl`
> 生成时间：2026-11-15T14:19:33.204Z
> 数据来源：eGMP 配置接口，只读分析，不修改平台。

## 对象概览

| 项 | 值 |
| --- | --- |
| 对象名称 | CAPA |
| 对象 code | `capa_plan__c` |
| 对象 id | `3a19df9c-485b-088a-ba92-c707490b4e43` |
| 生命周期 | CAPA生命周期 |
| lifecycleId | `3a19df9c-485b-dd78-59d6-bd7ec03bb9fe` |
| 启用生命周期 | 是 |
| 状态 | 15 启用 / 15 总数 |
| 用户动作 | 12 |
| 进入动作 | 22 |
| 字段 | 74 |
| 工作流 | 14 |
| 进入条件 | 未配置（0 条） |

## 状态与动作

### 1. CAPA申请（`init_status__c`）

- 状态 id：`7ff31a3a-253f-f36c-c6e3-3a19df9c4c83`
- sort：0；启用：是
- 用户动作：2；进入动作：2

**用户动作**

- **提交**（`submit__c`）：未配置具体动作；发起工作流
  - 提交
- **取消**（`cancel__c`）：未配置具体动作；修改生命周期状态
  - 取消

**进入动作**

- **（未命名）**：行为 38
  - 获取CAPA设置实例
- **（未命名）**：行为 38
  - 赋值CAPA设置相关字段

### 2. CAPA申请审核（`pending_initial_approval__c`）

- 状态 id：`1f14bdce-3a80-2f92-7ad2-3a19dfede7c7`
- sort：1；启用：是
- 用户动作：0；进入动作：1

**用户动作**

- 无

**进入动作**

- **（未命名）**：行为 16
  - 生成业务编号

### 3. 事件调查、初始风险评估及原因分析（`determine_responsible_department__c`）

- 状态 id：`e29752a0-1ee0-4588-7160-3a19dfee3a6b`
- sort：2；启用：是
- 用户动作：2；进入动作：1

**用户动作**

- **提交风评小组评估**（`submit__c`）：未配置具体动作
  - 提交
- **取消**（`cancel__c`）：未配置具体动作
  - 取消

**进入动作**

- **（未命名）**：行为 29；发起工作流；工作流「【CAPA】负责人提醒待办」
  - 完成提醒任务，发起提醒工作流
  - workflowId：`3a19fe1b-a4ac-5570-f512-0250589521e4`

### 4. 风险评估审核（`incident_investigation_initial_risk_assessment_and_cause__c`）

- 状态 id：`cb400434-eed2-787a-f50a-3a249bafc40b`
- sort：3；启用：是
- 用户动作：0；进入动作：0

**用户动作**

- 无

**进入动作**

- 无

### 5. 制定行动措施（`formulating_actions__c`）

- 状态 id：`65a13bd0-961d-6e43-bddb-3a19dfee6e75`
- sort：4；启用：是
- 用户动作：2；进入动作：2

**用户动作**

- **提交**（`submit__c`）：未配置具体动作
  - 提交
- **取消**（`cancel__c`）：未配置具体动作
  - 取消

**进入动作**

- **（未命名）**：修改相关对象生命周期状态
  - 修改【部门CAPA计划】状态至【制定措施】
- **（未命名）**：行为 29；发起工作流；工作流「【CAPA】制订行动措施提醒」
  - 发起需要各部门制定行动措施提醒工作流
  - workflowId：`3a19ff5c-738a-e57c-e6fe-844c289f4408`

### 6. 待发起计划审核（`ready_for_approval__c`）

- 状态 id：`4240ee6d-da01-6617-d414-3a19dfeedd19`
- sort：5；启用：是
- 用户动作：3；进入动作：3

**用户动作**

- **提交**（`submit__c`）：未配置具体动作
  - 提交
- **取消**（`cancel__c`）：未配置具体动作
  - 取消
- **退回至各部门制定措施**（`return_to_department__c`）：未配置具体动作
  - 退回各部门制定措施

**进入动作**

- **（未命名）**：行为 29
  - 完成提醒任务
- **（未命名）**：发起工作流；工作流「【CAPA】待发起计划待办」
  - 发起提醒工作流
  - workflowId：`3a19febc-1d0e-dca8-20c6-8c23bfbe4d4d`
- **（未命名）**：发起工作流；工作流「CAPA-进行评估」
  - 若由偏差发起，填写评估内容
  - workflowId：`3a238d5b-391c-f86c-513b-bd656a9f763b`

### 7. 行动措施审核（`pending_approval__c`）

- 状态 id：`94cbfed6-d132-fe8f-4d4a-3a19dfef1771`
- sort：6；启用：是
- 用户动作：0；进入动作：0

**用户动作**

- 无

**进入动作**

- 无

### 8. 等待措施执行完成（`in_implementation__c`）

- 状态 id：`0adef087-36bd-2958-536b-3a19dfef4c60`
- sort：7；启用：是
- 用户动作：0；进入动作：5

**用户动作**

- 无

**进入动作**

- **（未命名）**：行为 16
  - 生成业务编号
- **（未命名）**：修改相关对象生命周期状态；修改相关对象生命周期状态
  - 修改无前置行动措施的CAPA行动措施状态为[执行中]；存在前置行动措施的CAPA行动措施状态为[等待前置行动措施完成]
- **（未命名）**：修改相关对象生命周期状态
  - 修改【部门CAPA计划】状态至【完成】
- **（未命名）**：行为 29；发起工作流；工作流「【CAPA】CAPA行动措施执行提醒待办」
  - 完成提醒任务，发起提醒任务
  - workflowId：`3a19ff5a-5df6-bb6c-a4f7-484965b16849`
- **（未命名）**：母菜单
  - 检查同级CAPA状态，若都通过，则跳转至影响对象处置方式

### 9. CAPA关闭（`capa_closed__c`）

- 状态 id：`4dc3038b-183e-c14c-0f20-3a19dfef7f30`
- sort：8；启用：是
- 用户动作：1；进入动作：1

**用户动作**

- **提交**（`submit__c`）：未配置具体动作
  - 提交

**进入动作**

- **（未命名）**：行为 29；发起工作流；工作流「【CAPA】管理者代表提醒待办」
  - 完成提醒任务，重新发起提醒任务
  - workflowId：`3a24adce-3aaf-3767-0b4a-f5b7675b8fcb`

### 10. CAPA关闭审核（`pending_closure_approval__c`）

- 状态 id：`a22dff82-85b9-e8f8-f98e-3a19dfefb16f`
- sort：9；启用：是
- 用户动作：0；进入动作：0

**用户动作**

- 无

**进入动作**

- 无

### 11. 等待有效性评估完成（`pending_effectiveness_check__c`）

- 状态 id：`bc45f3b0-ee6b-fe86-d7f9-3a19dfefe218`
- sort：10；启用：是
- 用户动作：1；进入动作：1

**用户动作**

- **提交**（`submit__c`）：未配置具体动作
  - 提交

**进入动作**

- **（未命名）**：行为 29；发起工作流；工作流「【CAPA】等待有效性评估完成」
  - 发起提醒工作流
  - workflowId：`3a19ff52-8906-b6ab-dd4f-8a1b25384005`

### 12. 等待有效性评估结果审核（`pending_effectiveness_check_approval__c`）

- 状态 id：`7157546d-fd28-82e9-4bbc-3a19dff02b43`
- sort：11；启用：是
- 用户动作：0；进入动作：0

**用户动作**

- 无

**进入动作**

- 无

### 13. 已完成（`complete_status__c`）

- 状态 id：`45756e82-ea35-8d58-557c-3a19df9c4c85`
- sort：12；启用：是
- 用户动作：1；进入动作：3

**用户动作**

- **下载**（`download_report__c`）：未配置具体动作
  - 下载运行报告

**进入动作**

- **（未命名）**：行为 29
  - 完成提醒任务
- **（未命名）**：修改相关对象生命周期状态
  - 修改【审计管理-内审计划】状态为【内审关闭结论】
- **（未命名）**：修改相关对象生命周期状态
  - 修改【审计管理-外审计划】状态为【审计关闭结论】

### 14. 取消审核（`pending_cancellation_approval__c`）

- 状态 id：`53980a2c-7039-27e2-c18f-3a19dff06da0`
- sort：13；启用：是
- 用户动作：0；进入动作：0

**用户动作**

- 无

**进入动作**

- 无

### 15. 已取消（`cancelled__c`）

- 状态 id：`9b04ae01-b38c-a207-2872-3a19dff099ec`
- sort：14；启用：是
- 用户动作：0；进入动作：3

**用户动作**

- 无

**进入动作**

- **（未命名）**：行为 29
  - 完成提醒任务
- **（未命名）**：修改相关对象生命周期状态
  - 修改【行动措施】状态为【取消】
- **（未命名）**：修改相关对象生命周期状态
  - 修改【部门CAPA计划】状态至【取消】

## 工作流解析

| # | 工作流 | code | status | 版本 | 允许自动启动 | 直接触发 | 步骤 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 【CAPA】负责人提醒待办 | `capa_closed_notice__c` | 20 | 7 | 是 | 事件调查、初始风险评估及原因分析 / 完成提醒任务，发起提醒工作流（进入动作） | 3 |
| 2 | 【CAPA】制订行动措施提醒 | `capa_formulating_actions_notice__c` | 20 | 5 | 是 | 制定行动措施 / 发起需要各部门制定行动措施提醒工作流（进入动作） | 3 |
| 3 | 【CAPA】待发起计划待办 | `capa_ready_for_approval__c` | 20 | 5 | 是 | 待发起计划审核 / 发起提醒工作流（进入动作） | 3 |
| 4 | CAPA-进行评估 | `capa_make_an_assessment__c` | 20 | 9 | 是 | 待发起计划审核 / 若由偏差发起，填写评估内容（进入动作） | 8 |
| 5 | 【CAPA】CAPA行动措施执行提醒待办 | `capa_determine_department_notice__c` | 20 | 3 | 是 | 等待措施执行完成 / 完成提醒任务，发起提醒任务（进入动作） | 3 |
| 6 | 【CAPA】管理者代表提醒待办 | `capa_manager_representative_reminds_to_be_done__c` | 20 | 1 | 是 | CAPA关闭 / 完成提醒任务，重新发起提醒任务（进入动作） | 3 |
| 7 | 【CAPA】等待有效性评估完成 | `capa_pending_effectiveness_check__c` | 20 | 4 | 是 | 等待有效性评估完成 / 发起提醒工作流（进入动作） | 3 |
| 8 | CAPA风险评估审核 | `capa_risk_assessment_review__c` | 20 | 8 | 否 | 未反查到直接触发点（按对象工作流保留） | 7 |
| 9 | 【CAPA】行动措施审核 | `capa_department_action_review__c` | 20 | 20 | 否 | 状态绑定：待发起计划审核、制定行动措施（未反查到直接动作） | 7 |
| 10 | 【CAPA】申请审核 | `capa_application_review__c` | 20 | 15 | 否 | 未反查到直接触发点（按对象工作流保留） | 8 |
| 11 | 【CAPA】关闭审核 | `capa_closed_review__c` | 20 | 11 | 否 | 未反查到直接触发点（按对象工作流保留） | 8 |
| 12 | 【CPAP】不需要各部门制定行动措施提醒 | `The_department_formulates_action_measures__c` | 20 | 3 | 是 | 状态绑定：制定行动措施（未反查到直接动作） | 3 |
| 13 | 【CAPA】取消审核 | `capa_cancel_review__c` | 20 | 7 | 否 | 未反查到直接触发点（按对象工作流保留） | 8 |
| 14 | 【CAPA】有效性评估审核 | `capa_effectiveness_check_review__c` | 20 | 4 | 否 | 未反查到直接触发点（按对象工作流保留） | 9 |

### 1. 【CAPA】负责人提醒待办

- workflowBasicId：`3a19fe1b-a4ac-5570-f512-0250589521e4`
- workflowConfigId：`9ed84b8c-2861-69a5-d45d-3a24b21b2f4d`
- code：`capa_closed_notice__c`；status：20；版本：7；isAllowTrigger：是
- 触发：事件调查、初始风险评估及原因分析 / 完成提醒任务，发起提醒工作流（进入动作）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `capa_closed_notice_Start__c` | — | 任务：提醒责任人 |
| 2 | 任务 | 任务：提醒责任人 | `taks_owner__c` | 通知任务 | 结束 |
| 3 | 结束 | 结束 | `capa_closed_notice_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 任务：提醒责任人。
- 2. [任务] 任务：提醒责任人：通知任务；下一步 结束。
- 3. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 没有直接改本对象状态的 behaviorType=9 动作。
- 该流程只做提醒/审批/读取，不改任何生命周期状态。

### 2. 【CAPA】制订行动措施提醒

- workflowBasicId：`3a19ff5c-738a-e57c-e6fe-844c289f4408`
- workflowConfigId：`c8b28d50-1b28-ebea-d793-3a24b7416a87`
- code：`capa_formulating_actions_notice__c`；status：20；版本：5；isAllowTrigger：是
- 触发：制定行动措施 / 发起需要各部门制定行动措施提醒工作流（进入动作）
- 生命周期状态绑定：制定行动措施（`65a13bd0-961d-6e43-bddb-3a19dfee6e75`）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `capa_determine_department_notice_Start__c` | — | 任务：责任人 |
| 2 | 任务 | 任务：责任人 | `task_owner__c` | 通知任务 | 结束 |
| 3 | 结束 | 结束 | `capa_determine_department_notice_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 任务：责任人。
- 2. [任务] 任务：责任人：通知任务；下一步 结束。
- 3. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 没有直接改本对象状态的 behaviorType=9 动作。
- 该流程只做提醒/审批/读取，不改任何生命周期状态。

### 3. 【CAPA】待发起计划待办

- workflowBasicId：`3a19febc-1d0e-dca8-20c6-8c23bfbe4d4d`
- workflowConfigId：`98604136-7d95-97ce-51fa-3a1a4bdc1590`
- code：`capa_ready_for_approval__c`；status：20；版本：5；isAllowTrigger：是
- 触发：待发起计划审核 / 发起提醒工作流（进入动作）
- 生命周期状态绑定：待发起计划审核（`4240ee6d-da01-6617-d414-3a19dfeedd19`）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `capa_ready_for_approval_Start__c` | — | 任务：责任人 |
| 2 | 任务 | 任务：责任人 | `task_owner__c` | 通知任务 | 结束 |
| 3 | 结束 | 结束 | `capa_ready_for_approval_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 任务：责任人。
- 2. [任务] 任务：责任人：通知任务；下一步 结束。
- 3. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 没有直接改本对象状态的 behaviorType=9 动作。
- 该流程只做提醒/审批/读取，不改任何生命周期状态。

### 4. CAPA-进行评估

- workflowBasicId：`3a238d5b-391c-f86c-513b-bd656a9f763b`
- workflowConfigId：`4c3c585c-7055-2c55-ad70-3a23f996fb39`
- code：`capa_make_an_assessment__c`；status：20；版本：9；isAllowTrigger：是
- 触发：待发起计划审核 / 若由偏差发起，填写评估内容（进入动作）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `capa_make_an_assessment_Start__c` | — | 任务：研发负责人填写 |
| 2 | 任务 | 任务：研发负责人填写 | `task_filled_in_by_the_rd_leader__c` | 任务 | 任务：质量负责人填写 |
| 3 | 任务 | 任务：质量负责人填写 | `task_to_be_filled_in_by_the_quality_manager__c` | 任务 | 任务：质量部负责人填写 |
| 4 | 任务 | 任务：质量部负责人填写 | `task_filled_in_by_the_person_in_charge_of_the_quality__c` | 任务 | 判断：偏差状态 |
| 5 | 判断 | 判断：偏差状态 | `judgment_deviation_state__c` | 规则 1 条；有否则分支 | — |
| 6 | 动作 | 动作：修改偏差状态为“填写受影响处理方式” | `action_modify_the_deviation_status_to_fill_in_the_affected__c` | 修改相关对象生命周期状态：关联对象 3a19d9a1-43c0-f65b-715a-05193519734b → 57b0814c-1db8-a305-84a6-3a238d1e78fb | 结束 |
| 7 | 动作 | 动作：修改偏差状态“填写受影响的结果” | `action_modify_deviation_state_fill_in_impacted_result__c` | 修改相关对象生命周期状态：关联对象 3a19d9a1-43c0-f65b-715a-05193519734b → a2b0668b-cf1c-a913-44c5-3a238d2d2aaf | 结束 |
| 8 | 结束 | 结束 | `capa_make_an_assessment_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 任务：研发负责人填写。
- 2. [任务] 任务：研发负责人填写：任务；下一步 任务：质量负责人填写。
- 3. [任务] 任务：质量负责人填写：任务；下一步 任务：质量部负责人填写。
- 4. [任务] 任务：质量部负责人填写：任务；下一步 判断：偏差状态。
- 5. [判断] 判断：偏差状态：规则1 → f1a5fa74-5c53-9a69-e004-3a23f996fb3e；否则 → 7083add5-5f7e-f25a-636b-3a23f996fb3e。
- 6. [动作] 动作：修改偏差状态为“填写受影响处理方式”：修改相关对象生命周期状态：关联对象 3a19d9a1-43c0-f65b-715a-05193519734b → 57b0814c-1db8-a305-84a6-3a238d1e78fb；下一步 结束。
- 7. [动作] 动作：修改偏差状态“填写受影响的结果”：修改相关对象生命周期状态：关联对象 3a19d9a1-43c0-f65b-715a-05193519734b → a2b0668b-cf1c-a913-44c5-3a238d2d2aaf；下一步 结束。
- 8. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 没有直接改本对象状态的 behaviorType=9 动作。
- 「动作：修改偏差状态为“填写受影响处理方式”」改关联对象 `3a19d9a1-43c0-f65b-715a-05193519734b` 的状态 `57b0814c-1db8-a305-84a6-3a238d1e78fb`（关联对象，不是本对象生命周期边）
- 「动作：修改偏差状态“填写受影响的结果”」改关联对象 `3a19d9a1-43c0-f65b-715a-05193519734b` 的状态 `a2b0668b-cf1c-a913-44c5-3a238d2d2aaf`（关联对象，不是本对象生命周期边）

### 5. 【CAPA】CAPA行动措施执行提醒待办

- workflowBasicId：`3a19ff5a-5df6-bb6c-a4f7-484965b16849`
- workflowConfigId：`5d3ecbd5-0e28-e685-bd4d-3a1d66039f83`
- code：`capa_determine_department_notice__c`；status：20；版本：3；isAllowTrigger：是
- 触发：等待措施执行完成 / 完成提醒任务，发起提醒任务（进入动作）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `capa_determine_department_notice_Start__c` | — | 任务：责任人 |
| 2 | 任务 | 任务：责任人 | `task_owner__c` | 通知任务 | 结束 |
| 3 | 结束 | 结束 | `capa_determine_department_notice_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 任务：责任人。
- 2. [任务] 任务：责任人：通知任务；下一步 结束。
- 3. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 没有直接改本对象状态的 behaviorType=9 动作。
- 该流程只做提醒/审批/读取，不改任何生命周期状态。

### 6. 【CAPA】管理者代表提醒待办

- workflowBasicId：`3a24adce-3aaf-3767-0b4a-f5b7675b8fcb`
- workflowConfigId：`3a24adce-3ab3-f10d-a6ca-9e446f6b5a39`
- code：`capa_manager_representative_reminds_to_be_done__c`；status：20；版本：1；isAllowTrigger：是
- 触发：CAPA关闭 / 完成提醒任务，重新发起提醒任务（进入动作）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `capa_closed_notice_Start__c` | — | 任务：提醒责任人 |
| 2 | 任务 | 任务：提醒责任人 | `taks_owner__c` | 通知任务 | 结束 |
| 3 | 结束 | 结束 | `capa_closed_notice_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 任务：提醒责任人。
- 2. [任务] 任务：提醒责任人：通知任务；下一步 结束。
- 3. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 没有直接改本对象状态的 behaviorType=9 动作。
- 该流程只做提醒/审批/读取，不改任何生命周期状态。

### 7. 【CAPA】等待有效性评估完成

- workflowBasicId：`3a19ff52-8906-b6ab-dd4f-8a1b25384005`
- workflowConfigId：`45821200-ee99-7136-94c6-3a24bb8a7db3`
- code：`capa_pending_effectiveness_check__c`；status：20；版本：4；isAllowTrigger：是
- 触发：等待有效性评估完成 / 发起提醒工作流（进入动作）
- 生命周期状态绑定：等待有效性评估完成（`bc45f3b0-ee6b-fe86-d7f9-3a19dfefe218`）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `capa_pending_effectiveness_check_Start__c` | — | 任务：责任人 |
| 2 | 任务 | 任务：责任人 | `task_owner__c` | 通知任务 | 结束 |
| 3 | 结束 | 结束 | `capa_pending_effectiveness_check_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 任务：责任人。
- 2. [任务] 任务：责任人：通知任务；下一步 结束。
- 3. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 没有直接改本对象状态的 behaviorType=9 动作。
- 该流程只做提醒/审批/读取，不改任何生命周期状态。

### 8. CAPA风险评估审核

- workflowBasicId：`3a24aa6c-04ec-f8de-9c77-226feef4c3d3`
- workflowConfigId：`afd9c2c0-16bc-ce19-7c6d-3a24dad56cfd`
- code：`capa_risk_assessment_review__c`；status：20；版本：8；isAllowTrigger：否
- 触发：未反查到直接触发点（按对象工作流保留）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `capa_risk_assessment_review_Start__c` | — | 动作：修改状态风险评估审核 |
| 2 | 动作 | 动作：修改状态风险评估审核 | `action_modify_status_risk_assessment_review__c` | 修改生命周期状态：本对象 → 风险评估审核 | 任务：风险评估审核 |
| 3 | 任务 | 任务：风险评估审核 | `task_risk_assessment_review__c` | 任务；需要审批；审批按钮：同意/不同意 | 判断：审核结果 |
| 4 | 判断 | 判断：审核结果 | `judgement_audit_results__c` | 规则 1 条；有否则分支 | — |
| 5 | 动作 | 动作：修改状态初步评估 | `action_modify_state_preliminary_assessment__c` | 修改生命周期状态：本对象 → 事件调查、初始风险评估及原因分析 | 结束 |
| 6 | 动作 | 动作：修改状态制定行动措施 | `action_modify_status_and_formulate_action_measures__c` | 修改生命周期状态：本对象 → 制定行动措施 | 结束 |
| 7 | 结束 | 结束 | `capa_risk_assessment_review_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 动作：修改状态风险评估审核。
- 2. [动作] 动作：修改状态风险评估审核：修改生命周期状态：本对象 → 风险评估审核；下一步 任务：风险评估审核。
- 3. [任务] 任务：风险评估审核：任务；需要审批；审批按钮：同意/不同意；下一步 判断：审核结果。
- 4. [判断] 判断：审核结果：规则1 → 6a5feb8b-51e5-790d-04f3-3a24dad56d04；否则 → b0d26c6f-7403-107e-7df9-3a24dad56d04。
- 5. [动作] 动作：修改状态初步评估：修改生命周期状态：本对象 → 事件调查、初始风险评估及原因分析；下一步 结束。
- 6. [动作] 动作：修改状态制定行动措施：修改生命周期状态：本对象 → 制定行动措施；下一步 结束。
- 7. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 「动作：修改状态风险评估审核」→ 「风险评估审核」
- 「动作：修改状态初步评估」→ 「事件调查、初始风险评估及原因分析」
- 「动作：修改状态制定行动措施」→ 「制定行动措施」

**异常与待确认**

- 没有状态动作直接引用这条工作流，也没有生命周期状态绑定；可能是对象级手动/事件流程。

### 9. 【CAPA】行动措施审核

- workflowBasicId：`3a19fdf2-47fe-2504-92e6-beae3586e8f6`
- workflowConfigId：`340716e7-c474-3edb-6a0c-3a24b4a9981f`
- code：`capa_department_action_review__c`；status：20；版本：20；isAllowTrigger：否
- 触发：状态绑定：待发起计划审核、制定行动措施（未反查到直接动作）
- 生命周期状态绑定：待发起计划审核（`4240ee6d-da01-6617-d414-3a19dfeedd19`）、制定行动措施（`65a13bd0-961d-6e43-bddb-3a19dfee6e75`）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `capa_application_review_Start__c` | — | 修改状态：行动措施审核 |
| 2 | 动作 | 修改状态：行动措施审核 | `change_status_pending_initial_approval__c` | 修改生命周期状态：本对象 → 行动措施审核 | 任务：CAPA行动措施审核 |
| 3 | 任务 | 任务：CAPA行动措施审核 | `task_reviewer__c` | 任务；需要审批；审批按钮：同意/拒绝 | 判断：审核人 |
| 4 | 判断 | 判断：审核人 | `judgment_approver__c` | 规则 1 条；有否则分支 | — |
| 5 | 动作 | 修改状态：制定行动措施 | `change_status_formulating_actions__c` | 修改生命周期状态：本对象 → 制定行动措施 | 结束 |
| 6 | 动作 | 状态：等待行动措施完成 | `Pending_completion_of_action_measures__c` | 修改生命周期状态：本对象 → 等待措施执行完成 | 结束 |
| 7 | 结束 | 结束 | `capa_application_review_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 修改状态：行动措施审核。
- 2. [动作] 修改状态：行动措施审核：修改生命周期状态：本对象 → 行动措施审核；下一步 任务：CAPA行动措施审核。
- 3. [任务] 任务：CAPA行动措施审核：任务；需要审批；审批按钮：同意/拒绝；下一步 判断：审核人。
- 4. [判断] 判断：审核人：规则1 → a8988ecf-7ffe-5eb2-60fc-3a24b4ace960；否则 → faf92f63-0f54-e412-8286-3a24b4a99825。
- 5. [动作] 修改状态：制定行动措施：修改生命周期状态：本对象 → 制定行动措施；下一步 结束。
- 6. [动作] 状态：等待行动措施完成：修改生命周期状态：本对象 → 等待措施执行完成；下一步 结束。
- 7. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 「修改状态：行动措施审核」→ 「行动措施审核」
- 「修改状态：制定行动措施」→ 「制定行动措施」
- 「状态：等待行动措施完成」→ 「等待措施执行完成」

**异常与待确认**

- 状态动作没有直接引用这条工作流；按工作流上的生命周期状态绑定展示，实际触发点可能是状态事件。

### 10. 【CAPA】申请审核

- workflowBasicId：`3a19e00f-71b7-776b-d737-9d59c93a7847`
- workflowConfigId：`934243ed-7303-728a-f318-3a24aa616fe9`
- code：`capa_application_review__c`；status：20；版本：15；isAllowTrigger：否
- 触发：未反查到直接触发点（按对象工作流保留）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `capa_application_review_Start__c` | — | 修改状态：申请审核 |
| 2 | 动作 | 修改状态：申请审核 | `change_status_pending_initial_approval__c` | 修改生命周期状态：本对象 → CAPA申请审核；修改相关对象生命周期状态：关联对象 3a19e4d2-d27a-02e9-506b-b7504536a9ab → 6c379024-76dc-af41-fac9-3a19e50b467b | 任务：CAPA申请审核 |
| 3 | 任务 | 任务：CAPA申请审核 | `task_reviewer__c` | 任务；需要审批；审批按钮：同意/拒绝 | 判断：CAPA申请审核 |
| 4 | 判断 | 判断：CAPA申请审核 | `judgment_approver__c` | 规则 1 条；有否则分支 | — |
| 5 | 动作 | 修改状态：申请 | `change_status_init__c` | 修改生命周期状态：本对象 → CAPA申请；修改相关对象生命周期状态：关联对象 3a19e4c7-e1f5-c776-d052-a4bb3da4282e → 63d32955-4cac-7f96-9def-3a19e4c7e731；修改相关对象生命周期状态：关联对象 3a19e4d2-d27a-02e9-506b-b7504536a9ab → 236c8973-1fc4-4547-0af7-3a19e4d2d6d9 | 任务：审核退回 |
| 6 | 任务 | 任务：审核退回 | `task_reject__c` | 通知任务 | 结束 |
| 7 | 动作 | 修改状态：初步评估 | `change_status_formulating_actions__c` | 修改生命周期状态：本对象 → 事件调查、初始风险评估及原因分析 | 结束 |
| 8 | 结束 | 结束 | `capa_application_review_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 修改状态：申请审核。
- 2. [动作] 修改状态：申请审核：修改生命周期状态：本对象 → CAPA申请审核；修改相关对象生命周期状态：关联对象 3a19e4d2-d27a-02e9-506b-b7504536a9ab → 6c379024-76dc-af41-fac9-3a19e50b467b；下一步 任务：CAPA申请审核。
- 3. [任务] 任务：CAPA申请审核：任务；需要审批；审批按钮：同意/拒绝；下一步 判断：CAPA申请审核。
- 4. [判断] 判断：CAPA申请审核：规则1 → 4729b309-8d3f-5cd6-fe2f-3a24aa616ff3；否则 → b9751d90-faff-d60d-14c0-3a24aa616ff3。
- 5. [动作] 修改状态：申请：修改生命周期状态：本对象 → CAPA申请；修改相关对象生命周期状态：关联对象 3a19e4c7-e1f5-c776-d052-a4bb3da4282e → 63d32955-4cac-7f96-9def-3a19e4c7e731；修改相关对象生命周期状态：关联对象 3a19e4d2-d27a-02e9-506b-b7504536a9ab → 236c8973-1fc4-4547-0af7-3a19e4d2d6d9；下一步 任务：审核退回。
- 6. [任务] 任务：审核退回：通知任务；下一步 结束。
- 7. [动作] 修改状态：初步评估：修改生命周期状态：本对象 → 事件调查、初始风险评估及原因分析；下一步 结束。
- 8. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 「修改状态：申请审核」→ 「CAPA申请审核」
- 「修改状态：申请」→ 「CAPA申请」
- 「修改状态：初步评估」→ 「事件调查、初始风险评估及原因分析」
- 「修改状态：申请审核」改关联对象 `3a19e4d2-d27a-02e9-506b-b7504536a9ab` 的状态 `6c379024-76dc-af41-fac9-3a19e50b467b`（关联对象，不是本对象生命周期边）
- 「修改状态：申请」改关联对象 `3a19e4c7-e1f5-c776-d052-a4bb3da4282e` 的状态 `63d32955-4cac-7f96-9def-3a19e4c7e731`（关联对象，不是本对象生命周期边）
- 「修改状态：申请」改关联对象 `3a19e4d2-d27a-02e9-506b-b7504536a9ab` 的状态 `236c8973-1fc4-4547-0af7-3a19e4d2d6d9`（关联对象，不是本对象生命周期边）

**异常与待确认**

- 没有状态动作直接引用这条工作流，也没有生命周期状态绑定；可能是对象级手动/事件流程。

### 11. 【CAPA】关闭审核

- workflowBasicId：`3a19ea48-2d15-0358-d1f6-61a188e1a51c`
- workflowConfigId：`789705b2-7ed9-de2e-dc66-3a2376fd9642`
- code：`capa_closed_review__c`；status：20；版本：11；isAllowTrigger：否
- 触发：未反查到直接触发点（按对象工作流保留）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `capa_closed_review_Start__c` | — | 修改状态：CAPA关闭审核 |
| 2 | 动作 | 修改状态：CAPA关闭审核 | `change_status_pending_closure_approval__c` | 修改生命周期状态：本对象 → CAPA关闭审核 | 任务：CAPA关闭审核 |
| 3 | 任务 | 任务：CAPA关闭审核 | `task_reviewer__c` | 任务；需要审批；审批按钮：同意/拒绝 | 判断：CAPA关闭审核 |
| 4 | 判断 | 判断：CAPA关闭审核 | `judgment_approval__c` | 规则 2 条；有否则分支 | — |
| 5 | 动作 | 修改状态：已完成 | `change_status_completed__c` | 修改生命周期状态：本对象 → 已完成 | 结束 |
| 6 | 动作 | 修改状态：CAPA关闭 | `change_status_capa_closed__c` | 修改生命周期状态：本对象 → CAPA关闭 | 结束 |
| 7 | 动作 | 修改状态：等待有效性评估完成 | `change_status_pending_effectiveness_check__c` | 修改生命周期状态：本对象 → 等待有效性评估完成 | 结束 |
| 8 | 结束 | 结束 | `capa_closed_review_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 修改状态：CAPA关闭审核。
- 2. [动作] 修改状态：CAPA关闭审核：修改生命周期状态：本对象 → CAPA关闭审核；下一步 任务：CAPA关闭审核。
- 3. [任务] 任务：CAPA关闭审核：任务；需要审批；审批按钮：同意/拒绝；下一步 判断：CAPA关闭审核。
- 4. [判断] 判断：CAPA关闭审核：规则1 → f5a25f57-055a-49f3-4268-3a2376fd964b；规则2 → 1fd850cc-b44e-8531-bd27-3a2376fd964b；否则 → dfc3134a-edfa-0719-e56f-3a2376fd964b。
- 5. [动作] 修改状态：已完成：修改生命周期状态：本对象 → 已完成；下一步 结束。
- 6. [动作] 修改状态：CAPA关闭：修改生命周期状态：本对象 → CAPA关闭；下一步 结束。
- 7. [动作] 修改状态：等待有效性评估完成：修改生命周期状态：本对象 → 等待有效性评估完成；下一步 结束。
- 8. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 「修改状态：CAPA关闭审核」→ 「CAPA关闭审核」
- 「修改状态：已完成」→ 「已完成」
- 「修改状态：CAPA关闭」→ 「CAPA关闭」
- 「修改状态：等待有效性评估完成」→ 「等待有效性评估完成」

**异常与待确认**

- 没有状态动作直接引用这条工作流，也没有生命周期状态绑定；可能是对象级手动/事件流程。

### 12. 【CPAP】不需要各部门制定行动措施提醒

- workflowBasicId：`3a1d6a72-e246-8f7e-cf59-39ba8fd5ec95`
- workflowConfigId：`6c7a0a3e-da19-eb45-fb08-3a1d6a744e40`
- code：`The_department_formulates_action_measures__c`；status：20；版本：3；isAllowTrigger：是
- 触发：状态绑定：制定行动措施（未反查到直接动作）
- 生命周期状态绑定：制定行动措施（`65a13bd0-961d-6e43-bddb-3a19dfee6e75`）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `The_department_formulates_action_measures_Start__c` | — | 任务：责任人 |
| 2 | 任务 | 任务：责任人 | `task_owner__c` | 通知任务 | 结束 |
| 3 | 结束 | 结束 | `The_department_formulates_action_measures_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 任务：责任人。
- 2. [任务] 任务：责任人：通知任务；下一步 结束。
- 3. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 没有直接改本对象状态的 behaviorType=9 动作。
- 该流程只做提醒/审批/读取，不改任何生命周期状态。

**异常与待确认**

- 状态动作没有直接引用这条工作流；按工作流上的生命周期状态绑定展示，实际触发点可能是状态事件。

### 13. 【CAPA】取消审核

- workflowBasicId：`3a19ea98-45a7-06b7-84dc-d2c06035fc1d`
- workflowConfigId：`768845bc-6b45-897e-4427-3a1d63edb836`
- code：`capa_cancel_review__c`；status：20；版本：7；isAllowTrigger：否
- 触发：未反查到直接触发点（按对象工作流保留）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `capa_effectiveness_check_review_Start__c` | — | 修改状态：取消审核 |
| 2 | 动作 | 修改状态：取消审核 | `change_status_cancellation_approval__c` | 修改生命周期状态：本对象 → 取消审核 | 任务：CAPA取消审核 |
| 3 | 任务 | 任务：CAPA取消审核 | `task_reviewer__c` | 任务；需要审批；审批按钮：同意/拒绝 | 判断：审核人 |
| 4 | 判断 | 判断：审核人 | `judgment_reviewer__c` | 规则 2 条；有否则分支 | — |
| 5 | 动作 | 修改状态：待发起计划审核 | `change_status_ready_for_approval__c` | 修改生命周期状态：本对象 → 待发起计划审核 | 结束 |
| 6 | 动作 | 修改状态：等待措施执行完成 | `change_status_in_implementation__c` | 修改生命周期状态：本对象 → 等待措施执行完成 | 结束 |
| 7 | 动作 | 修改状态：已取消 | `change_status_cancelled__c` | 修改生命周期状态：本对象 → 已取消 | 结束 |
| 8 | 结束 | 结束 | `capa_effectiveness_check_review_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 修改状态：取消审核。
- 2. [动作] 修改状态：取消审核：修改生命周期状态：本对象 → 取消审核；下一步 任务：CAPA取消审核。
- 3. [任务] 任务：CAPA取消审核：任务；需要审批；审批按钮：同意/拒绝；下一步 判断：审核人。
- 4. [判断] 判断：审核人：规则1 → ddc5b906-9e7e-2a37-8295-3a1d63edb83b；规则2 → 1a06a465-7b72-4111-0bdd-3a1d63edb83b；否则 → cbc37496-693b-3cc5-3550-3a1d63edb83b。
- 5. [动作] 修改状态：待发起计划审核：修改生命周期状态：本对象 → 待发起计划审核；下一步 结束。
- 6. [动作] 修改状态：等待措施执行完成：修改生命周期状态：本对象 → 等待措施执行完成；下一步 结束。
- 7. [动作] 修改状态：已取消：修改生命周期状态：本对象 → 已取消；下一步 结束。
- 8. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 「修改状态：取消审核」→ 「取消审核」
- 「修改状态：待发起计划审核」→ 「待发起计划审核」
- 「修改状态：等待措施执行完成」→ 「等待措施执行完成」
- 「修改状态：已取消」→ 「已取消」

**异常与待确认**

- 没有状态动作直接引用这条工作流，也没有生命周期状态绑定；可能是对象级手动/事件流程。

### 14. 【CAPA】有效性评估审核

- workflowBasicId：`3a19ea85-4333-e291-3ae9-eca97eb30fb4`
- workflowConfigId：`7db8ce25-8b0c-2e67-c243-3a1a4bd7fbfd`
- code：`capa_effectiveness_check_review__c`；status：20；版本：4；isAllowTrigger：否
- 触发：未反查到直接触发点（按对象工作流保留）

| 序号 | 类型 | 名称 | code | 配置摘要 | 下一步 |
| --- | --- | --- | --- | --- | --- |
| 1 | 开始 | 开始 | `capa_effectiveness_check_review_Start__c` | — | 修改状态：等待有效性评估结果审核 |
| 2 | 动作 | 修改状态：等待有效性评估结果审核 | `change_status_effectiveness_check_approval__c` | 修改生命周期状态：本对象 → 等待有效性评估结果审核 | 任务：审核人 |
| 3 | 任务 | 任务：审核人 | `task_reviewer__c` | 任务；需要审批；审批按钮：同意/拒绝 | 判断：审核人 |
| 4 | 判断 | 判断：审核人 | `judgment_reviewer__c` | 规则 1 条；有否则分支 | — |
| 5 | 任务 | 任务：批准人 | `task_approval__c` | 任务；需要审批；审批按钮：同意/拒绝 | 判断：批准人 |
| 6 | 判断 | 判断：批准人 | `judgment_approver__c` | 规则 1 条；有否则分支 | — |
| 7 | 动作 | 修改状态：等待有效性评估完成 | `change_status_pending_effectiveness_check__c` | 修改生命周期状态：本对象 → 等待有效性评估完成 | 结束 |
| 8 | 动作 | 修改状态：已完成 | `change_status_completed__c` | 修改生命周期状态：本对象 → 已完成 | 结束 |
| 9 | 结束 | 结束 | `capa_effectiveness_check_review_End__c` | — | — |

**流程阅读**

- 1. [开始] 开始；下一步 修改状态：等待有效性评估结果审核。
- 2. [动作] 修改状态：等待有效性评估结果审核：修改生命周期状态：本对象 → 等待有效性评估结果审核；下一步 任务：审核人。
- 3. [任务] 任务：审核人：任务；需要审批；审批按钮：同意/拒绝；下一步 判断：审核人。
- 4. [判断] 判断：审核人：规则1 → 33acb572-1814-45a7-3c9d-3a1a4be10433；否则 → 938dd2a3-31c7-1e88-31aa-3a1a4bd7fc05。
- 5. [任务] 任务：批准人：任务；需要审批；审批按钮：同意/拒绝；下一步 判断：批准人。
- 6. [判断] 判断：批准人：规则1 → d5708ae1-6f90-c323-8bf6-3a1a4bd7fc05；否则 → 938dd2a3-31c7-1e88-31aa-3a1a4bd7fc05。
- 7. [动作] 修改状态：等待有效性评估完成：修改生命周期状态：本对象 → 等待有效性评估完成；下一步 结束。
- 8. [动作] 修改状态：已完成：修改生命周期状态：本对象 → 已完成；下一步 结束。
- 9. [结束] 结束；下一步 结束。

**对生命周期的影响**

- 「修改状态：等待有效性评估结果审核」→ 「等待有效性评估结果审核」
- 「修改状态：等待有效性评估完成」→ 「等待有效性评估完成」
- 「修改状态：已完成」→ 「已完成」

**异常与待确认**

- 没有状态动作直接引用这条工作流，也没有生命周期状态绑定；可能是对象级手动/事件流程。

## 自动观察与风险

- 8 个状态没有用户动作：CAPA申请审核（pending_initial_approval__c）、风险评估审核（incident_investigation_initial_risk_assessment_and_cause__c）、行动措施审核（pending_approval__c）、等待措施执行完成（in_implementation__c）、CAPA关闭审核（pending_closure_approval__c）、等待有效性评估结果审核（pending_effectiveness_check_approval__c）、取消审核（pending_cancellation_approval__c）、已取消（cancelled__c）。这些状态需要工作流状态步骤或自动动作接管；否则会缺少人工出口。
- 5 个状态既没有用户动作也没有进入动作：风险评估审核、行动措施审核、CAPA关闭审核、等待有效性评估结果审核、取消审核。它们完全依赖外部工作流/事件驱动。
- 1 个动作带「发起工作流」行为，但没有读到 workflowId：提交。可能只是读取层没解析到 behaviorValue，也可能是漏配，需用工作流页面核对。
- 行为类型映射不全：行为 38、行为 16、行为 29、母菜单。页面/文档暂时只能显示数字或泛化标签，建议补映射表。
- 有 7 个进入动作会修改相关对象的生命周期状态（behaviorType 46），改本对象前要一起检查关联对象。
- 6 条工作流里存在 behaviorType=9 的本对象状态变更：CAPA风险评估审核、【CAPA】行动措施审核、【CAPA】申请审核、【CAPA】关闭审核、【CAPA】取消审核、【CAPA】有效性评估审核。文档的工作流章节逐条列出了动作节点；drawio 每个工作流单独一页。
- 5 条工作流既没有状态动作直接引用，也没有 lifecycleStatusIds 绑定：CAPA风险评估审核、【CAPA】申请审核、【CAPA】关闭审核、【CAPA】取消审核、【CAPA】有效性评估审核。触发点需要平台侧确认，文档按“对象工作流”保留。
- 生命周期进入条件为 0 条且可读：属于“未配置”，不是读取失败。

## 生成说明

- 本文档由 akso-workbench 对象分析页生成，数据来自 eGMP 配置接口。
- 状态顺序按 `status.sort` 排列；生命周期总览页的状态链也按 sort 排列，不是平台声明的迁移顺序。
- 工作流章节来自 `GetWorkflowSteps` + `GetWorkflowStepWithDetails` 的真实步骤；behaviorType=46 只画成关联对象影响，不画成本对象生命周期边。
- drawio 文件包含“生命周期总览”页和每条工作流一页，建议用 diagrams.net / drawio 打开。

## 字段表

共 74 个字段：启用 72 个，停用 2 个；必填 1 个，自定义 58 个。

| # | 字段名 | code | 类型 | 必填 | 唯一 | 来源 | 引用 / 选项集 | 状态 |
| ---: | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Id | `global_id__sys` | ID | — | — | 系统 | — | 启用 |
| 2 | 外部Id | `external_id__sys` | ID | — | — | 系统 | — | 启用 |
| 3 | 业务编号 | `name__ak` | 文本 | — | — | 预置 | — | 启用 |
| 4 | 版本号 | `version__sys` | 文本 | — | — | 系统 | — | 启用 |
| 5 | 创建人 | `created_by__sys` | 对象 | — | — | 系统 | — | 启用 |
| 6 | 创建时间 | `created_time__sys` | 日期时间 | — | — | 系统 | — | 启用 |
| 7 | 更新人 | `modified_by__sys` | 对象 | — | — | 系统 | — | 启用 |
| 8 | 更新时间 | `modified_time__sys` | 日期时间 | — | — | 系统 | — | 启用 |
| 9 | 是否删除 | `is_deleted__sys` | 布尔 | — | — | 系统 | — | 启用 |
| 10 | 所属对象 | `object_id__sys` | 组件 | — | — | 系统 | — | 启用 |
| 11 | 对象类型 | `object_type_id__ak` | 组件 | — | — | 预置 | — | 启用 |
| 12 | 记录状态 | `state__ak` | 单选 | — | — | 预置 | 选项集 `99999999-0000-0000-0001-000000000001` | 启用 |
| 13 | 状态 | `status_id__sys` | 组件 | — | — | 系统 | — | 启用 |
| 14 | 所属质量组织 | `own_company__ak` | 对象 | — | — | 预置 | — | 启用 |
| 15 | CAPA设置 | `capa_setting__c` | 对象 | — | — | 自定义 | — | 启用 |
| 16 | 是否由各部门制定行动措施 | `department_capa_plan_required__c` | 布尔 | — | — | 自定义 | — | 启用 |
| 17 | 行动措施制定时间 | `action_develop_phase__c` | 单选 | — | — | 自定义 | 选项集 `3426016a-2dc6-ebd4-e3ef-3a19df935009` | 启用 |
| 18 | 有效性评估目标 | `effectiveness_check_target__c` | 单选 | — | — | 自定义 | 选项集 `047068c0-e18e-6db7-1be0-3a19df94458d` | 启用 |
| 19 | 是否启用DMS系统 | `is_document_module_enabled__c` | 布尔 | — | — | 自定义 | — | 启用 |
| 20 | 是否启用TMS系统 | `is_training_module_enabled__c` | 布尔 | — | — | 自定义 | — | 启用 |
| 21 | 整改部门责任人 | `owner__c` | 对象 | — | — | 自定义 | — | 启用 |
| 22 | 整改部门 | `responsible_department__c` | 对象 | — | — | 自定义 | — | 启用 |
| 23 | 发起日期 | `initiated_date__c` | 日期 | — | — | 自定义 | — | 启用 |
| 24 | 来源 | `source__c` | 单选 | — | — | 自定义 | 选项集 `edeea72a-dbcc-893f-195c-3a19dfd01242` | 启用 |
| 25 | 其他来源说明 | `other_source__c` | 文本 | — | — | 自定义 | — | 启用 |
| 26 | 偏差 | `deviation__c` | 对象 | — | — | 自定义 | — | 启用 |
| 27 | 问题描述 | `defect_description__c` | 文本 | — | — | 自定义 | — | 启用 |
| 28 | 风险评估 | `risk_assessment__c` | 文本 | — | — | 自定义 | — | 启用 |
| 29 | 根因结论 | `defect_root_cause__c` | 文本 | — | — | 自定义 | — | 启用 |
| 30 | 关闭结论 | `closure_conclusion__c` | 文本 | — | — | 自定义 | — | 启用 |
| 31 | 是否需要有效性评估 | `effectiveness_check_required__c` | 布尔 | — | — | 自定义 | — | 启用 |
| 32 | 不需要有效性评估的原因 | `no_effectiveness_check_reaseon__c` | 文本 | — | — | 自定义 | — | 启用 |
| 33 | 有效性评估标准 | `effectiveness_check_protocol__c` | 文本 | — | — | 自定义 | — | 启用 |
| 34 | 有效性评估频率 | `effectiveness_check_frequency__c` | 单选 | — | — | 自定义 | 选项集 `a94e19f0-a2f9-fe94-cbd7-3a19dfe2566d` | 启用 |
| 35 | 评估开始时间 | `effectiveness_check_begin_date__c` | 日期 | — | — | 自定义 | — | 启用 |
| 36 | 评估截止时间 | `effectiveness_check_end_date__c` | 日期 | — | — | 自定义 | — | 启用 |
| 37 | CAPA是否有效 | `is_capa_effective__c` | 布尔 | — | — | 自定义 | — | 启用 |
| 38 | 有效性评估实际完成日期 | `effectiveness_check_completion_date__c` | 日期 | — | — | 自定义 | — | 启用 |
| 39 | 无效原因 | `ineffective_reason__c` | 文本 | — | — | 自定义 | — | 启用 |
| 40 | 是否发起新的CAPA | `new_capa_required__c` | 布尔 | — | — | 自定义 | — | 启用 |
| 41 | 取消原因 | `cancel_reason__c` | 文本 | — | — | 自定义 | — | 启用 |
| 42 | 是否存在活跃流程 | `exist_active_flow__sys` | 布尔 | — | — | 系统 | — | 启用 |
| 43 | 生命周期阶段 | `lifecycle_stage__ak` | 单选 | — | — | 预置 | 选项集 `fd932677-8a9e-b108-5415-3a19e4c971c5` | 启用 |
| 44 | 投诉编号 | `Complaint_Number__c` | 对象 | — | — | 自定义 | — | 启用 |
| 45 | 审计管理 | `audit_mgt__c` | 对象 | — | — | 自定义 | — | 启用 |
| 46 | CAPA计划 | `CAPA_Plan__c` | 对象 | — | — | 自定义 | — | 启用 |
| 47 | 召回管理 | `Recall_Management__c` | 对象 | — | — | 自定义 | — | 启用 |
| 48 | OOS/OOT管理 | `OOS_OOT_Management__c` | 对象 | — | — | 自定义 | — | 启用 |
| 49 | CAPA行动措施数量 | `Number_of_CAPA_actions__c` | 统计 | — | — | 自定义 | — | 启用 |
| 50 | 补充证据 | `supplementary_evidence__c` | 对象 | — | — | 自定义 | — | 启用 |
| 51 | 执行部门负责人 | `head_of_executive_department__c` | 对象 | 是 | — | 自定义 | — | 停用 |
| 52 | 对产品的影响 | `product_impact__c` | 文本 | — | — | 自定义 | — | 启用 |
| 53 | 对合规性影响 | `impact_on_compliance__c` | 文本 | — | — | 自定义 | — | 启用 |
| 54 | 验证与确认需求 | `verification_validation_requirements__c` | 文本 | — | — | 自定义 | — | 启用 |
| 55 | 研发负责人 | `rd_leader__c` | 对象 | — | — | 自定义 | — | 启用 |
| 56 | 质量负责人 | `quality_director__c` | 对象 | — | — | 自定义 | — | 启用 |
| 57 | 质量部负责人 | `head_of_quality__c` | 对象 | — | — | 自定义 | — | 启用 |
| 58 | 初步评估偏差等级 | `deviation_level__c` | 单选 | — | — | 自定义 | 选项集 `3d49a991-5701-31c0-183c-3a19d9ea9047` | 启用 |
| 59 | 受影响产品范围评估 | `affected_product_scope_assessment__c` | 文本 | — | — | 自定义 | — | 启用 |
| 60 | 是否影响已生产的产品 | `does_it_affect_products_already_produced__c` | 布尔 | — | — | 自定义 | — | 启用 |
| 61 | 已生产产品位置 | `produced_product_location__c` | 单选 | — | — | 自定义 | 选项集 `641fd68e-3c41-0347-7aaf-3a2499749131` | 启用 |
| 62 | 补救措施 | `remedial_action__c` | 单选 | — | — | 自定义 | 选项集 `cae85b30-431c-4758-bbe5-3a2499765d7a` | 启用 |
| 63 | 是否要采取补救措施 | `whether_remedial_measures_should_be_taken__c` | 布尔 | — | — | 自定义 | — | 启用 |
| 64 | 其他补救措施 | `otherwise_cure_the_non_compliance__c` | 文本 | — | — | 自定义 | — | 启用 |
| 65 | 是否影响质量体系 | `does_it_affect_the_quality_system__c` | 布尔 | — | — | 自定义 | — | 启用 |
| 66 | 是否影响物料 | `affect_material__c` | 布尔 | — | — | 自定义 | — | 启用 |
| 67 | 对质量体系的影响 | `impact_on_quality_system__c` | 文本 | — | — | 自定义 | — | 启用 |
| 68 | 对物料的影响 | `impact_on_materials__c` | 文本 | — | — | 自定义 | — | 启用 |
| 69 | 事件调查 | `incident_investigation__c` | 文本 | — | — | 自定义 | — | 启用 |
| 70 | 整改后残余风险是否可接受 | `is_the_residual_risk_acceptable_after__c` | 布尔 | — | — | 自定义 | — | 启用 |
| 71 | 额外控制措施 | `additional_control_measures__c` | 文本 | — | — | 自定义 | — | 启用 |
| 72 | 是否关闭 | `video_off_in_suspend__c` | 布尔 | — | — | 自定义 | — | 启用 |
| 73 | 评审是否涉及研发 | `does_the_review_involve_r_d__c` | 单选 | — | — | 自定义 | 选项集 `3f5bf938-1d91-8ac8-6f25-3a24b4e625f9` | 停用 |
| 74 | 风险评估是否涉及研发 | `does_the_risk_assessment_involve_r_d__c` | 单选 | — | — | 自定义 | 选项集 `3f5bf938-1d91-8ac8-6f25-3a24b4e625f9` | 启用 |
